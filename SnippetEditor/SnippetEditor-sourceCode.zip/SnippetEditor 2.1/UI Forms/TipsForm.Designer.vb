﻿'-----------------------------------------------------------------
' Copyright (c) Bill McCarthy.  
' This code and information are provided "as is"  without warranty
' of any kind either expressed or implied. Use at your own risk.
'-----------------------------------------------------------------

Option Strict On : Option Explicit On : Option Compare Binary : Option Infer On




<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TipsForm
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
      Me.WebBrowser1 = New System.Windows.Forms.WebBrowser
      Me.SuspendLayout()
      '
      'WebBrowser1
      '
      Me.WebBrowser1.AllowWebBrowserDrop = False
      Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
      Me.WebBrowser1.Location = New System.Drawing.Point(0, 0)
      Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
      Me.WebBrowser1.Name = "WebBrowser1"
      Me.WebBrowser1.Size = New System.Drawing.Size(723, 376)
      Me.WebBrowser1.TabIndex = 0
      '
      'TipsForm
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(723, 376)
      Me.Controls.Add(Me.WebBrowser1)
      Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
      Me.Name = "TipsForm"
      Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
      Me.Text = "Tips"
      Me.ResumeLayout(False)

   End Sub
   Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
End Class
